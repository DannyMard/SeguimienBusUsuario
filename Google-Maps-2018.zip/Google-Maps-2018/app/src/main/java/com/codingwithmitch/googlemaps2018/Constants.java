package com.codingwithmitch.googlemaps2018;

public class Constants {

    public static final int ERROR_DIALOG_REQUEST = 9001;
}
